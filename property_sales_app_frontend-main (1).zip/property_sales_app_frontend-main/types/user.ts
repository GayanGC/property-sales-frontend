
type User = {
    id: string;
    email: string;
    username: string;
    roles: string[];
};

export default User;