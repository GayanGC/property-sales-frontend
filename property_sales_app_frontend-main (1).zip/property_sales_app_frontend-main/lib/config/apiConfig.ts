export const API_URL = "http://localhost:8080/api";

//https://collection.cloudinary.com/doggnkzdk/413b686f3ffafcec5bb20ffee7e96dd4
export const HEADERS = {
  "Content-Type": "application/json",
};